<template>
    <div>ajsdlfkjasdl;kfjkl;asdjfkl;asjdfl;kasjdfl;kasjdfl;kasjdf;lkasjd;lfkjasdfl;k</div>
</template>

<script>
export default {
    props: ['name'],
};
</script>